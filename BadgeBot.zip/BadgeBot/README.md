# Discord Active Developer Badge Bot 🤖

A simple Discord bot with slash commands to help you qualify for the **Discord Active Developer Badge**.

## Features ✨

- **8 Slash Commands**: Basic utilities + webhook functionality
- **Webhook Integration**: Send messages and rich embeds via webhooks
- **Easy Setup**: Simple configuration process
- **Active Developer Ready**: Meets all requirements for the badge

## Quick Start Guide 🚀

### Step 1: Create Your Discord Bot

1. Go to [Discord Developer Portal](https://discord.com/developers/applications)
2. Click **"New Application"** and give it a name
3. Go to the **"Bot"** tab on the left
4. Click **"Reset Token"** and copy your bot token (save it securely!)
5. Under the same Bot tab, copy your **Application ID** (also called Client ID)

### Step 2: Configure Environment Variables

In your Replit project, add these secrets:

1. Click the **"Secrets"** tab (lock icon) in the left sidebar
2. Add required secrets:
   - **Key**: `DISCORD_BOT_TOKEN` → **Value**: Your bot token from step 1
   - **Key**: `DISCORD_CLIENT_ID` → **Value**: Your application ID from step 1
3. **(Optional) For webhook features**, add:
   - **Key**: `DISCORD_WEBHOOK_URL` → **Value**: Your Discord webhook URL

### Step 3: Register Commands

Run this command in the Shell to register your slash commands:

```bash
npm run register
```

You should see a success message confirming that 8 commands were registered.

### Step 4: Invite Your Bot to a Server

1. Go back to the [Discord Developer Portal](https://discord.com/developers/applications)
2. Select your application → **OAuth2** → **URL Generator**
3. Select scopes: **`bot`** and **`applications.commands`**
4. Select permissions: **`Send Messages`** (minimum required)
5. Copy the generated URL and open it in your browser
6. Select a server and authorize the bot

### Step 5: Start the Bot

The bot should start automatically, but if not, click the **Run** button at the top of Replit.

You should see:
```
✅ Bot is ready! Logged in as YourBotName#1234
```

### Step 6: Test Your Bot

In your Discord server, type `/` and you should see your bot's commands:

**Basic Commands:**
- `/ping` - Check bot latency
- `/help` - Show all commands
- `/roll` - Roll a dice (1-6)
- `/coinflip` - Flip a coin (Heads/Tails)
- `/random` - Get a random number (1-100)

**Webhook Commands** (requires DISCORD_WEBHOOK_URL secret):
- `/webhook-send` - Send a custom message via webhook
- `/webhook-embed` - Send a rich embed message via webhook
- `/webhook-info` - View webhook information

### How to Create a Discord Webhook

To use webhook commands:
1. Right-click any channel in your Discord server
2. Click **"Edit Channel"** → **"Integrations"** → **"Webhooks"**
3. Click **"New Webhook"**, customize it, then **"Copy Webhook URL"**
4. Add the URL to your Replit Secrets as `DISCORD_WEBHOOK_URL`

## Getting the Active Developer Badge 🏆

1. Make sure your bot is running and has slash commands
2. **Use at least one command** in a server
3. Wait **24 hours** after the first command use
4. Visit the [Active Developer page](https://discord.com/developers/active-developer)
5. Claim your badge!

## Troubleshooting 🔧

**Bot won't start?**
- Check that `DISCORD_BOT_TOKEN` and `DISCORD_CLIENT_ID` are set in Secrets
- Make sure the token is valid (reset it in Discord Developer Portal if needed)

**Commands not showing?**
- Run `npm run register` to register commands
- Wait a few minutes (global commands can take up to 1 hour)
- Try restarting your Discord client

**Commands not working?**
- Make sure the bot has permission to send messages in the channel
- Check that the bot is online (should show green status)

## Support

Need help? Check out:
- [Discord.js Guide](https://discordjs.guide/)
- [Discord Developer Docs](https://discord.com/developers/docs)
- [Active Developer Badge FAQ](https://support-dev.discord.com/hc/en-us/articles/10113997751447)

---

Made with ❤️ for Discord developers
