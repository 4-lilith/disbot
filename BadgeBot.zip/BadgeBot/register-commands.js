const { REST, Routes } = require('discord.js');

const commands = [
  {
    name: 'ping',
    description: 'Check the bot latency and response time',
  },
  {
    name: 'help',
    description: 'Display all available commands and information',
  },
  {
    name: 'roll',
    description: 'Roll a dice (1-6)',
  },
  {
    name: 'coinflip',
    description: 'Flip a coin to get Heads or Tails',
  },
  {
    name: 'random',
    description: 'Generate a random number between 1 and 100',
  },
  {
    name: 'webhook-send',
    description: 'Send a message via webhook',
    options: [
      {
        name: 'message',
        type: 3,
        description: 'The message to send',
        required: true,
      },
      {
        name: 'username',
        type: 3,
        description: 'Custom username for the webhook (optional)',
        required: false,
      },
    ],
  },
  {
    name: 'webhook-embed',
    description: 'Send a rich embed message via webhook',
    options: [
      {
        name: 'title',
        type: 3,
        description: 'Embed title',
        required: true,
      },
      {
        name: 'description',
        type: 3,
        description: 'Embed description',
        required: true,
      },
      {
        name: 'color',
        type: 3,
        description: 'Embed color (hex format like #ff0000, default: #0099ff)',
        required: false,
      },
      {
        name: 'username',
        type: 3,
        description: 'Custom username for the webhook (optional)',
        required: false,
      },
    ],
  },
  {
    name: 'webhook-info',
    description: 'Get information about the configured webhook',
  },
];

const token = process.env.DISCORD_BOT_TOKEN;
const clientId = process.env.DISCORD_CLIENT_ID;

if (!token || !clientId) {
  console.error('❌ ERROR: Missing required environment variables!');
  console.error('Please set DISCORD_BOT_TOKEN and DISCORD_CLIENT_ID in your environment.');
  process.exit(1);
}

const rest = new REST({ version: '10' }).setToken(token);

(async () => {
  try {
    console.log('🔄 Started refreshing application (/) commands...');

    await rest.put(
      Routes.applicationCommands(clientId),
      { body: commands },
    );

    console.log('✅ Successfully registered application commands globally!');
    console.log(`📝 Registered ${commands.length} commands:`);
    commands.forEach(cmd => console.log(`   - /${cmd.name}: ${cmd.description}`));
    console.log('\n⏱️  Note: Global commands may take up to 1 hour to appear in all servers.');
    console.log('💡 Tip: Restart your Discord client to see commands faster.');
  } catch (error) {
    console.error('❌ Error registering commands:', error);
  }
})();
