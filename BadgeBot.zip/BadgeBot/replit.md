# Discord Active Developer Badge Bot

## Overview
A Discord bot built with Discord.js v14 that provides slash commands to help users qualify for the Discord Active Developer Badge. The bot includes fun utility commands and proper command handling.

## Recent Changes
- **2025-11-16**: Initial project setup with Node.js and Discord.js
- Created slash commands: ping, help, roll, coinflip, random
- Added webhook functionality with 3 new commands: webhook-send, webhook-embed, webhook-info
- Set up command registration system
- Integrated with Replit Discord connector for token management

## Project Architecture

### Technology Stack
- **Runtime**: Node.js 20
- **Discord Library**: Discord.js v14
- **Integration**: Replit Discord Connector (conn_discord_01KA5C8721MQ2ZZN1EV1WH72HM)

### Project Structure
```
/
├── index.js                 # Main bot file with event handlers and command logic
├── register-commands.js     # Script to register slash commands with Discord API
├── package.json             # Node.js dependencies and scripts
└── replit.md               # Project documentation
```

### Commands

**Basic Commands:**
1. **/ping** - Returns bot latency
2. **/help** - Displays all available commands
3. **/roll** - Rolls a dice (1-6)
4. **/coinflip** - Flips a coin (Heads/Tails)
5. **/random** - Generates random number (1-100)

**Webhook Commands:**
6. **/webhook-send** - Sends a custom message via webhook
7. **/webhook-embed** - Sends a rich embed message via webhook
8. **/webhook-info** - Displays information about the configured webhook

## Setup Instructions

### Prerequisites
1. Create a Discord bot at [Discord Developer Portal](https://discord.com/developers/applications)
2. Enable the following in Bot settings:
   - MESSAGE CONTENT INTENT (optional, not used but recommended)
   - SERVER MEMBERS INTENT (optional)
3. Copy your bot token and application (client) ID

### Environment Variables
Required environment variables:
- `DISCORD_BOT_TOKEN` - Your bot's token from Discord Developer Portal
- `DISCORD_CLIENT_ID` - Your bot's application ID

Optional environment variables (for webhook features):
- `DISCORD_WEBHOOK_URL` - Discord webhook URL for sending messages

### Installation Steps
1. Install dependencies: `npm install`
2. Register slash commands: `npm run register`
3. Start the bot: `npm start`

### Inviting the Bot
Use this URL structure to invite your bot (replace CLIENT_ID):
```
https://discord.com/api/oauth2/authorize?client_id=CLIENT_ID&permissions=2048&scope=bot%20applications.commands
```

Minimum permissions required:
- Send Messages (2048)
- Use Slash Commands (automatically included with applications.commands scope)

## Active Developer Badge
To qualify for the Active Developer Badge:
1. Create and verify a bot application
2. Have at least 1 slash command registered
3. Have the command used by at least 1 user in the last 30 days
4. Wait 24 hours after meeting requirements
5. Claim badge at [Discord Developer Portal](https://discord.com/developers/active-developer)

## Development Notes
- Bot uses minimal intents for better performance
- All commands respond publicly (not ephemeral) for better visibility
- Error handling included for command execution
- Ready event provides confirmation when bot comes online
